const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema(
  {
    // 订单表(订单id[数据库自动添加], 用户id，收货人，电话，收获地址，项目数组，支付状态，订单创建时间[自动添加]，订单更新时间[自动添加])
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },

    name: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    // 订单详情(包含所有下单的产品信息)
    orderItems: [
      // (产品id，产品名，价格，数量qty，图片)
      {
        productId: {
          type: mongoose.Schema.Types.ObjectId,
          required: true,
          ref: "Product",
        },
        name: { type: String, required: true },
        price: { type: Number, required: true },
        count: { type: Number, required: true },
        image: { type: String, required: true },
      },
    ],

    // 寄件地址
    shippingAddress: {
      type: String,
      required: true,
      // (详细地址，省份，城市，邮编)
      // address: { type: String, required: true },
      // province: { type: String, required: true },
      // city: { type: String, required: true },
      // postalCode: { type: String, required: true },
    },

    // 快递费
    shippingPrice: { type: Number, required: true, default: 0 },

    // 总费用
    totalPrice: { type: Number, required: true },

    // 是否已支付
    isPaid: {
      type: Boolean,
      required: true,
      default: false,
    },

    // 支付方式
    // paymentMethod: {
    //   type: String,
    //   default: "weChat",
    //   required: true,
    // },

    // 支付结果
    // paymentResult: {
    //   // (付款单id，状态，更新时间，详细地址)
    //   id: { type: String, required: true },
    //   status: { type: String, required: true },
    //   update_time: { type: String, required: true },
    //   email_address: { type: String, required: true },
    // },

    // 发货时间
    // deliveredTime: { type: Date },

    // 是否送达
    // isDelivered: { type: Boolean, required: true, default: false },

    // 创建订单时间
    createdTime: { type: Date, default: new Date().toISOString() },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const orderModel = mongoose.model("Order", orderSchema);

module.exports = orderModel;
