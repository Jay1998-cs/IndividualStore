const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    // (姓名, 邮箱, 密码, 是否为管理员)
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    isAdmin: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const userModel = mongoose.model("User", userSchema);

module.exports = userModel;
