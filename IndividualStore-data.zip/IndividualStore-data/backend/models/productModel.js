const mongoose = require("mongoose");

// 单个用户评论
const reviewSchema = new mongoose.Schema(
  {
    // (用户姓名，评分，评论)
    name: {
      type: String,
      required: true,
    },
    rating: {
      type: Number,
      required: true,
    },
    comment: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// 产品信息
const productSchema = new mongoose.Schema(
  {
    // (管理员id，产品名，图片，描述，品牌，分类，价格，库存，评分，评论数，所有评论)
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
    // 产品名
    name: {
      type: String,
      required: true,
    },
    // 产品图
    image: {
      type: String,
      required: true,
    },
    // 描述or简介
    description: {
      type: String,
      required: true,
    },
    // 品牌
    brand: {
      type: String,
      required: true,
    },
    // 分类
    category: {
      type: String,
      required: true,
    },
    // 价格
    price: {
      type: Number,
      required: true,
      default: 0,
    },
    // 库存
    countInStock: {
      type: Number,
      required: true,
      default: 0,
    },
    // 评分
    rating: {
      type: Number,
      required: true,
      default: 0,
    },
    // 评价数
    numReviews: {
      type: Number,
      required: true,
      default: 0,
    },
    // 所有用户的评价信息(数组)
    reivews: [reviewSchema],
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const productModel = mongoose.model("Product", productSchema);

module.exports = productModel;
