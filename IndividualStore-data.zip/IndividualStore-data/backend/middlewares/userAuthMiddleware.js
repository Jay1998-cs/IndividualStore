const jwt = require("jsonwebtoken");
const userModel = require("../models/userModel");

const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  // console.log(authHeader);

  // 判断是否携带目标类型的token
  if (authHeader && authHeader.startsWith(process.env.JWT_TYPE)) {
    // 验证verify请求头中的token
    try {
      const token = authHeader.split(" ")[1].trim();
      // console.log("token:", token);
      if (!!token) {
        // 合法token
        const decoded = jwt.verify(token, process.env.JWT_SECRETE);
        // console.log("decoded:", decoded);
        // 用户信息(除密码外)保存到请求头中
        req.user = await userModel.findById(decoded.id).select("-password");
        // 继续执行(路由)
        next();
      } else {
        // token为空
        res.status(401).json({
          hasError: true,
          message: "Empty Token",
        });
      }
    } catch (error) {
      // token有误
      res.status(401).json({
        hasError: true,
        message: "Invalid Token",
      });
    }
  } else {
    // 请求报文缺少相关Token字段
    res.status(404).json({
      hasError: true,
      message: "Invalid or Miss Token",
    });
  }
};

module.exports = authMiddleware;
