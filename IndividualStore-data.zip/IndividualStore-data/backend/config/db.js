const mongoose = require("mongoose");

// 连接数据库;
const connectDB = async () => {
  try {
    // 连接
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      useUnifiedTopology: true,
      useNewUrlParser: true,
      // useCreateIndex: true,
    });

    // 成功
    console.log("MongoDB 已连接: ", conn.connection.host);
    // console.log(conn.connection);
  } catch (error) {
    // 出错
    console.log(error);
    process.exit(1);
  }
};

module.exports = connectDB;
