const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const productRoute = require("./routes/productRoute");
const userRoute = require("./routes/userRoute");
const orderRoute = require("./routes/orderRoute");

// 引入.env文件中的配置
dotenv.config();

// 连接到数据库
connectDB();

// 创建服务
const app = express();

// 中间件
app.use(express.json());
// app.use(express.urlencoded());

///////////// Router
// 根路由
app.get("/", (req, res) => {
  res.send("Individual Store服务器");
});
// 商品路由
app.use("/api/products", productRoute);
// 用户路由
app.use("/api/users", userRoute);
// 订单路由
app.use("/api/orders", orderRoute);

/////////////
// 启动监听
const PORT = process.env.PORT;
const MODE = process.env.NODE_ENV;

app.listen(PORT || 5000, () => {
  console.log(`Individual Store Server:${PORT} Started...[${MODE}]`);
});
