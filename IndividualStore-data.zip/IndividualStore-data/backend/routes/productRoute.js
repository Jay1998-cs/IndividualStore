const express = require("express");
const {
  getProducts,
  getProductById,
} = require("../controllers/productController");

const router = express.Router();

// 获取所有商品
router.route("/").get(getProducts); // router.get("/", getProducts);

// 获取某个id商品
router.route("/:id").get(getProductById); // router.get("/:id", getProductById);

module.exports = router;
