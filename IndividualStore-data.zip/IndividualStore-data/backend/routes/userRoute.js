const express = require("express");
const {
  registerUser,
  loginAuthUser,
  getUserProfile,
  updateUserProfile,
} = require("../controllers/userController");
const authMiddleware = require("../middlewares/userAuthMiddleware");

const router = express.Router();

// 用户注册
router.post("/register", registerUser);

// 用户登录
router.post("/login", loginAuthUser);

// 获取用户详情信息，需要使用中间件authMiddleware进行身份验证
router
  .route("/profile")
  .get(authMiddleware, getUserProfile)
  .put(authMiddleware, updateUserProfile);

module.exports = router;
