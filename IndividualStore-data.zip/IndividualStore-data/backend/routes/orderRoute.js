const express = require("express");
const authMiddleware = require("../middlewares/userAuthMiddleware");
const {
  createItemOrder,
  getOrderById,
} = require("../controllers/orderController");

const router = express.Router();

router.route("/").post(authMiddleware, createItemOrder);

router.route("/:id").get(authMiddleware, getOrderById);

module.exports = router;
