const jwt = require("jsonwebtoken");

const generateJWToken = (id) => {
  // 为 用户id 注册token以用于加密
  return jwt.sign({ id }, process.env.JWT_SECRETE, {
    expiresIn: "3d", // 【有效期-->到期失效后怎么办？-->前端设置对应时间的定时器，失效前退出用户登录】
  });
};

module.exports = generateJWToken;
