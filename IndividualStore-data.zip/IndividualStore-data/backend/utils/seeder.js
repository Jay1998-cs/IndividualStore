const dotenv = require("dotenv");
const connectDB = require("../config/db");
const userModel = require("../models/userModel");
const productModel = require("../models/productModel");
const orderModel = require("../models/orderModel");
const users = require("../data/users");
const products = require("../data/products");

dotenv.config();
connectDB();

// 将样本数据插入数据库
const importData = async () => {
  try {
    // 销毁数据库中的样本数据
    await userModel.deleteMany();
    await productModel.deleteMany();
    await orderModel.deleteMany();

    // 插入user和product样本数据
    const createdUsers = await userModel.insertMany(users);
    const adminUser_id = createdUsers[0]._id;

    const sampleProducts = products.map((product) => ({
      user: adminUser_id,
      ...product,
    }));
    await productModel.insertMany(sampleProducts);

    console.log("样本数据插入成功!");
    process.exit();
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
};

// 销毁数据库中的样本数据
const destroyData = async () => {
  try {
    await userModel.deleteMany();
    await productModel.deleteMany();
    await orderModel.deleteMany();

    console.log("样本数据销毁成功!");
    process.exit();
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
};

//判断命令行执行的函数
if (process.argv[2] === "-d") {
  destroyData();
} else {
  importData();
}

// module.exports = importData;
// module.exports = destroyData;
