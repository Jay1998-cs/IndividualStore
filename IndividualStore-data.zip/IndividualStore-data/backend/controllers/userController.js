const userModel = require("../models/userModel");
const bcrypt = require("bcryptjs");
const generateJWToken = require("../utils/generateToken");

//@desc    注册一个新用户
//@route   POST/api/users
//@access  公开
const registerUser = async (req, res) => {
  // 从请求体中获取用户注册相关的信息
  const { name, email, password, isAdmin } = req.body;

  // 根据邮箱查询该用户是否已注册
  try {
    const userExisted = await userModel.findOne({ email });
    if (userExisted) {
      // 用户已注册
      res.status(400).json({
        hasError: true,
        message: "Email confilct, user existed.",
      });
    } else {
      // 注册新用户，信息存入数据库
      const secretePsw = bcrypt.hashSync(password); // 密码加密存入[参考data文件夹下的user创建]
      const user = await userModel.create({
        name,
        email,
        password: secretePsw,
        isAdmin,
      });

      // 注册后的用户信息返回前端
      res.json({
        hasError: false,
        userInfo: {
          _id: user._id,
          name: user.name,
          emial: user.email,
          isAdmin: user.isAdmin || false,
          token: generateJWToken(user._id), // JWT
        },
        message: "New user registered success",
      });
    }
  } catch (error) {
    // 数据库出错 或 密码加密失败
    res.json({
      hasError: true,
      message: error.message,
    });
  }
};

//@desc    用户身份验证 & 基于JsonwbToken
//@route   POST /api/users/login
//@access  公开
const loginAuthUser = async (req, res) => {
  // 获取用户输入的登录信息
  const { email: enteredEmail, password: enteredPassword } = req.body;
  // console.log("[authUser from userController.js]", req.body);

  // 查询用户邮箱是否存在
  const user = await userModel.findOne({ email: enteredEmail });
  if (user) {
    // 验证用户密码是否正确
    const isPawValid = await bcrypt.compare(enteredPassword, user.password);
    if (isPawValid) {
      // 合法用户，返回用户相关信息
      res.json({
        hasError: false,
        userInfo: {
          _id: user._id,
          name: user.name,
          email: user.email,
          isAdmin: user.isAdmin,
          token: generateJWToken(user._id), // JWT
        },
        message: "Valid User",
      });
    } else {
      // 密码错误
      return res.status(400).json({
        hasError: true,
        message: "Password Error",
      });
    }
  } else {
    // 用户不存在
    res.status(401).json({
      hasError: true,
      message: "Email Error",
    });
  }
};

//@desc    获取登录成功的用户信息
//@route   GET /api/users/profile
//@access  私密
const getUserProfile = async (req, res) => {
  // 在中间件authMiddleware中进行用户验证并将user信息嵌入请求头
  const { _id } = req.user;
  if (!_id) {
    res.status(404).json({
      hasError: true,
      message: "Missed User Identifier(id)",
    });
  }

  // 根据user._id,从数据库中获取并返回用户相关信息
  try {
    const user = await userModel.findById(_id);
    if (user) {
      // 找到目标用户，返回其profile
      res.json({
        hasError: false,
        userProfile: {
          _id: user._id,
          name: user.name,
          email: user.email,
          isAdmin: user.isAdmin,
        },
      });
    } else {
      // 未找到目标用户
      res.status(404).json({
        hasError: true,
        message: "User Not Found",
      });
    }
  } catch (error) {
    // 数据库出错
    res.json({
      hasError: true,
      message: error.message,
    });
  }
};

//@desc    更新用户信息
//@route   POST/api/profile
//@access  私密
const updateUserProfile = async (req, res) => {
  // 获取请求体中的待查询的用户数据
  const { _id, name, email, password, oldPassword } = req.body;
  // console.log("待更新用户信息:", _id, name, email, password, oldPassword);

  // 更新用户资料
  try {
    // 用户_id必需
    if (!_id) {
      throw new Error("invalid user, miss validation id");
    }

    // 待更新的数据为空，直接结束，因为无更新内容
    if (!name && !email && !password && !oldPassword) {
      throw new Error("nothing need to be updated");
    }

    // 获取数据库中存储的当前用户对象
    const user = await userModel.findById(_id);
    if (user) {
      // 若用户修改密码，需要验证输入密码的是否与数据库存储的一致
      if (oldPassword && password) {
        // 验证用户密码是否正确
        const isPawValid = await bcrypt.compare(oldPassword, user.password);
        if (!isPawValid) {
          throw new Error("password validation error");
        }
        // 相同密码，无需更新
        const isEqual = await bcrypt.compare(password, user.password);
        if (isEqual) {
          throw new Error("same password");
        }
      }
      if (password && !oldPassword) {
        throw new Error("password validation error, miss old password");
      }
      if (!password && oldPassword) {
        throw new Error("password validation error, miss password");
      }

      // 更新数据库中的用户信息，并得到更新后的用户对象
      const updatedUser = await userModel.findByIdAndUpdate(
        { _id: _id },
        {
          $set: {
            name: name || user.name,
            email: email || user.email,
            password: password ? bcrypt.hashSync(password) : user.password,
          },
        },
        {
          new: true, // 返回更新后的数据
        }
      );
      // console.log("updatedUser: ", updatedUser);

      // 返回更新后的数据到前端
      res.json({
        hasError: false,
        userInfo: {
          _id: updatedUser._id,
          name: updatedUser.name,
          email: updatedUser.email,
          isAdmin: updatedUser.isAdmin || false,
          token: generateJWToken(updatedUser._id), // JWT
        },
        message: "userInfo updated success",
      });
    } else {
      // 用户不存在
      throw new Error("user not found");
    }
  } catch (error) {
    const errorMessage =
      error.message?.length <= 100 && "update fail, " + error.message;
    // 数据库出错
    res.json({
      hasError: true,
      message: errorMessage,
    });
  }
};

// 导出
module.exports = {
  loginAuthUser,
  getUserProfile,
  registerUser,
  updateUserProfile,
};
