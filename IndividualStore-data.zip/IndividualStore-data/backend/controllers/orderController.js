const orderModel = require("../models/orderModel");

// @desc    用户提交订单，后端数据库创建并保存对应订单记录
// @route   POST /api/orders
// @access  私密
const createItemOrder = async (req, res) => {
  const {
    name,
    phone,
    shippingAddress,
    orderItems,
    shippingPrice,
    totalPrice,
  } = req.body;
  // console.log(req.body);

  const { _id: userId } = req.user; // 用户id
  // console.log(req.user);

  try {
    // 输入验证
    if (!userId) {
      console.log("userId:", userId);
      throw new Error("error: 缺少用户标识(id).");
    }
    if (!name || !phone || !shippingAddress) {
      console.log(name, phone, shippingAddress);
      throw new Error("error: 缺少收货人(name,phone,etc.)信息.");
    }
    if (!orderItems || !orderItems.length) {
      console.log("orderItems:", orderItems);
      throw new Error("error: 空订单(epmty orderItems), 无商品信息.");
    }
    if (totalPrice === undefined) {
      throw new Error("error: 缺少商品总额(totalPrice)数据");
    }
    if (shippingPrice === undefined) {
      throw new Error("error: 缺少运费(shippingPrice)数据.");
    }

    // 创建、添加订单记录到数据库
    const orderInfo = new orderModel({
      user: userId,
      name,
      phone,
      shippingAddress,
      orderItems,
      shippingPrice,
      totalPrice,
    });
    const orderCreated = await orderInfo.save(); // 保存
    // console.log("orderCreated: ", orderCreated);

    // 响应新新订单数据给前端
    res.status(200).json(orderCreated);
  } catch (error) {
    // 出错，反馈给前端
    res.status(400).json(error.message);
  }
};

// @desc    依据订单id获取订单及下单用户
// @route   POST /api/orders/:id
// @access  私密
const getOrderById = async (req, res) => {
  try {
    const _id = req.params.id;
    if (_id === undefined) {
      throw new Error("error: missed order id");
    }

    const order = await orderModel.findById(_id).populate("user", "name email");

    if (order) {
      res.json(order);
    } else {
      throw new Error("cannot find order data");
    }
  } catch (err) {
    res.status(500).json(err.message);
  }
};

module.exports = {
  createItemOrder,
  getOrderById,
};
