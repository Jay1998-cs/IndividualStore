const productModel = require("../models/productModel");

// 获取所有产品
const getProducts = (req, res) => {
  // const data = await productModel.find();
  // return res.json(data);
  productModel
    .find()
    .then((data) => res.json(data))
    .catch((error) =>
      res.status(500).json({
        error,
      })
    );
};

// 获取单个产品
const getProductById = (req, res) => {
  productModel
    .findById(req.params.id)
    .then((data) => {
      if (data) {
        return res.json(data);
      } else {
        return res.status(404).json({
          message: "404 NOT Found Product.",
        });
      }
    })
    .catch((error) =>
      res.status(500).json({
        message: "NOT Found Product." + error.message,
      })
    );
};

module.exports = { getProducts, getProductById };
