export const routePathDict = {
  home: "/",
  register: "/register",
  login: "/login",
  profile: "/profile",
  cart: "/cart/:id?",
  product_detail: "/products/:id",
  payment: "/payment",
};

export const defaultValues = {
  tokenPrefix: "Bearer",
  paymentMethod: "weChat",
};

export const backendApiURL = {
  orders: "/api/orders",
};
