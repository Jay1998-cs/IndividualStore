import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import UpdateUserNameForm from "./UpdateUserNameForm";
import UpdateUserPswForm from "./UpdateUserPswForm";
import UpdateUserEmailForm from "./UpdateUserEmailForm";
import UserOrderScreen from "./UserOrderScreen";
import axios from "axios";
import { USER_LOGIN_SUCCESS } from "../constants/userConstants";
import { useNavigate } from "react-router-dom";
import { defaultValues, routePathDict } from "../config/config";

const ProfileScreen = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isUpdateOk, setIsUpdateOk] = useState(false); // 记录userInfo是否更新成功
  const [backendErrorMsg, setBackendErrorMsg] = useState(""); // 更新时后台的错误报告

  // 获取当前用户信息，未登录时为{}
  const { userInfo = {} } = useSelector((state) => state.userInfoReducer);

  // 未登录用户，无法访问个人页，跳转到登录页
  useEffect(() => {
    if (!Object.keys(userInfo).length) {
      navigate(routePathDict.login);
    }
  }, [userInfo, navigate]);

  // 获取已登录的用户信息
  const { _id, token, name, email } = userInfo;
  const userAuthToken = defaultValues.tokenPrefix + " " + token;
  // console.log(userAuthToken);
  // console.log("get userInfo: ", _id, name, email);

  // 记录用户单击左侧项目的状态
  const optionClickInitState = {
    opt_name: false,
    opt_password: false,
    opt_email: false,
    opt_order: false,
  };
  const [optionClickState, setOptionClickState] =
    useState(optionClickInitState);

  // 页面首次加载的状态，用于显式页面初始内容
  const isMount = Object.values(optionClickState).every(
    (opt_state) => opt_state === false
  );

  // 左侧选项单击事件，例如单击"名称"，在右侧工作区显式对应内容
  const clickNameTxtHandler = () => {
    setOptionClickState((preState) => ({
      ...optionClickInitState,
      opt_name: true,
    }));

    // 初始化更新状态，因为在其他组件时该状态可能为true(例如,更新邮箱成功后又选择更新用户名)
    setIsUpdateOk(false);
    setBackendErrorMsg("");
  };

  const clickPasswordTxtHandler = () => {
    setOptionClickState((preState) => ({
      ...optionClickInitState,
      opt_password: true,
    }));

    setIsUpdateOk(false);
    setBackendErrorMsg("");
  };

  const clickEmalTxtHandler = () => {
    setOptionClickState((preState) => ({
      ...optionClickInitState,
      opt_email: true,
    }));

    setIsUpdateOk(false);
    setBackendErrorMsg("");
  };

  const clickOrderTxtHandler = () => {
    setOptionClickState((preState) => ({
      ...optionClickInitState,
      opt_order: true,
    }));

    setIsUpdateOk(false);
    setBackendErrorMsg("");
  };

  // 左册菜单列表数据，含若干选项：名称、密码、邮箱、订单
  const leftMenuList = [
    {
      desc: <span className="text">名称</span>,
      icon: <i className="icon fa-solid fa-text-slash"></i>,
      clickHandler: clickNameTxtHandler,
    },
    {
      desc: <span className="text">密码</span>,
      icon: <i className="icon fa-sharp fa-solid fa-file-signature"></i>,
      clickHandler: clickPasswordTxtHandler,
    },
    {
      desc: <span className="text">邮箱</span>,
      icon: <i className="icon fa-solid fa-envelope"></i>,
      clickHandler: clickEmalTxtHandler,
    },
    {
      desc: <span className="text">订单</span>,
      icon: <i className="icon fa-solid fa-clipboard-list"></i>,
      clickHandler: clickOrderTxtHandler,
    },
  ];

  // 左侧菜单列表组件
  const leftMenuStyle = leftMenuList.map((item, idx) => (
    <div key={idx} className="item" onClick={item.clickHandler}>
      {item.icon}
      {item.desc}
    </div>
  ));

  // 更新userInfo异步函数
  const updateUserInfoFunc = async (userInfo) => {
    // console.log("要更新的用户信息: ", userInfo); ////////////////
    // 初始化更新状态
    setIsUpdateOk(false); // 单击该按钮时表示正在进行更新，即更新未完成

    // 发送PUT报文，请求后端更新数据
    try {
      const { data } = await axios.put(
        "/api/users/profile",
        { ...userInfo },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: userAuthToken,
          },
        }
      );

      // 用户信息更新失败，后端出错
      if (data.hasError === true) {
        throw new Error("error: " + data.message);
      }

      // 用户信息更新成功
      dispatch({ type: USER_LOGIN_SUCCESS, payload: data }); // 更新已登录的用户状态(类似重新登录)
      localStorage.setItem("userInfo", JSON.stringify(data.userInfo)); // 用户更新后的信息缓存到本地
      setIsUpdateOk(true); // 更新成功
      setBackendErrorMsg(""); // 无错误信息(初始化)
    } catch (error) {
      setBackendErrorMsg(error.message); // 记录错误信息
      setIsUpdateOk(false); // 更新失败
      console.error(error);
    }
  };

  // 单击"确认"按钮事件，以更新用户信息
  const clickBtnHandler = (data) => {
    updateUserInfoFunc({ _id, ...data }); // 更新userInfo
  };

  // 渲染
  return (
    <div className="user-center-container">
      <div className="left-bar">
        <div className="userInfo">
          <div className="img-box">
            <i className="fa-solid fa-user"></i>
          </div>
          <div className="name">{name}</div>
        </div>
        <div className="menu">{leftMenuStyle}</div>
      </div>

      <div className="right-work-space">
        {(isMount || optionClickState.opt_name) && (
          <UpdateUserNameForm
            userName={name}
            clickBtnHandler={clickBtnHandler}
            isUpdateOk={isUpdateOk}
            backendErrorMsg={backendErrorMsg}
          />
        )}
        {optionClickState.opt_password && (
          <UpdateUserPswForm
            userEmail={email}
            clickBtnHandler={clickBtnHandler}
            isUpdateOk={isUpdateOk}
            backendErrorMsg={backendErrorMsg}
          />
        )}
        {optionClickState.opt_email && (
          <UpdateUserEmailForm
            userEmail={email}
            clickBtnHandler={clickBtnHandler}
            isUpdateOk={isUpdateOk}
            backendErrorMsg={backendErrorMsg}
          />
        )}
        {optionClickState.opt_order && (
          <UserOrderScreen
            clickBtnHandler={clickBtnHandler}
            isUpdateOk={isUpdateOk}
            backendErrorMsg={backendErrorMsg}
          />
        )}
      </div>
    </div>
  );
};

export default ProfileScreen;
