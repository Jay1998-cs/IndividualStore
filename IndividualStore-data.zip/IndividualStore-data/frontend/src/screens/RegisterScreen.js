import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
// import { userRegisterAct } from "../actions/userActions";
import { USER_LOGIN_SUCCESS } from "../constants/userConstants";
import axios from "axios";

const RegisterScreen = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // 记录用户名称、邮箱、密码、确认密码的输入内容
  const userInfoInitialState = { name: "", email: "", password: "" };
  const [userRegisterInfo, setUserRegisterInfo] =
    useState(userInfoInitialState);
  const { name, email, password } = userRegisterInfo; // 名称、邮箱、密码
  const [confirmPsw, setConfirmPsw] = useState(""); // 确认密码

  // 注册状态：正在处理中、注册失败信息、注册成功标识
  const [registerState, setRegisterState] = useState({});
  const {
    isProcessing = false,
    errorMessage = "",
    isSuccess = false,
  } = registerState;

  // 处理成功注册的用户，跳转到首页
  useEffect(() => {
    if (isSuccess) {
      // 页面重定向，默认跳转到首页 xxxxx
      const redirectUrl = window.location.search
        ? window.location.search.split[1]
        : "/";

      navigate(redirectUrl);

      // 【更新用户登录信息 userinfo，增加一个update类型的action】
    }
  }, [isSuccess, navigate, dispatch]);

  // 输入验证
  const checkInputed = (name, email, password, confirmPsw) => {
    let isValid = false;
    let message = "";
    if (!name || !email || !password || !password || !confirmPsw) {
      isValid = false;
      message = "error: 存在空(empty)输入.";
    } else if (password !== confirmPsw) {
      isValid = false;
      message = "error: 两次输入的密码不一致.";
    } else {
      isValid = true;
      message = "...正在注册中...";
    }
    return { isValid, message };
  };

  // 注册按钮单击事件
  const clickRegisterBtnHandler = async (e) => {
    e.preventDefault();

    // 更新状态为:正在处理(注册)中
    setRegisterState((preState) => ({
      ...preState,
      isProcessing: true,
      errorMessage: "",
      isSuccess: false,
    }));

    // 输入验证
    const { isValid, message } = checkInputed(
      name,
      email,
      password,
      confirmPsw
    );

    // 不合法输入，无法注册
    if (!isValid) {
      setRegisterState((preState) => ({
        ...preState,
        isProcessing: false,
        errorMessage: message,
        isSuccess: false,
      }));
      return;
    }

    console.log(registerState);

    // 请求头
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    try {
      // 发送注册请求，得到注册后的用户信息
      const { data } = await axios.post(
        "/api/users/register",
        { name, email, password },
        config
      );

      console.log("data: ", data); /////////////////////////////////

      // 更新成功注册的状态
      setRegisterState((preState) => ({
        ...preState,
        isProcessing: false,
        errorMessage: "",
        isSuccess: true,
      }));

      // 更新登录用户状态，注册成功的用户直接切换到已登录状态
      dispatch({ type: USER_LOGIN_SUCCESS, payload: data });

      // // 成功登录的用户数据缓存到本地
      localStorage.setItem("userInfo", JSON.stringify(data.userInfo));
    } catch (error) {
      console.error(error);
      // 用户注册发生错误，更新状态
      setRegisterState((preState) => ({
        ...preState,
        isProcessing: false,
        errorMessage: error.response?.data?.message || error.message,
        isSuccess: false,
      }));
    }
  };

  // 邮箱输入事件
  const emailInputHandler = (e) => {
    setUserRegisterInfo((preState) => ({ ...preState, email: e.target.value }));
  };

  // 用户名输入事件
  const nameInputHandler = (e) => {
    setUserRegisterInfo((preState) => ({ ...preState, name: e.target.value }));
  };

  // 密码输入事件
  const passwordInputHandler = (e) => {
    setUserRegisterInfo((preState) => ({
      ...preState,
      password: e.target.value,
      isSuccess: false,
    }));
  };

  // 确认密码输入事件
  const passwordConfirmHandler = (e) => {
    setConfirmPsw(e.target.value);
  };

  return (
    <div className="user_form_container">
      <div className="user_form_content register_page">
        <h3>新用户注册</h3>

        <div className="userInfo_form">
          <label htmlFor="name">名称:</label>
          <input
            id="name"
            type="name"
            value={name}
            onChange={nameInputHandler}
          />
          <label htmlFor="email">邮箱:</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={emailInputHandler}
          />
          <label htmlFor="password">密码:</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={passwordInputHandler}
          />
          <label htmlFor="passwordConfirm">确认密码:</label>
          <input
            id="passwordConfirm"
            type="password"
            value={confirmPsw}
            onChange={passwordConfirmHandler}
          />

          {isProcessing && <div className="tip">...正在注册...</div>}
          {errorMessage && <div className="errorMessage">{errorMessage}</div>}
        </div>

        <button className="submit_btn" onClick={clickRegisterBtnHandler}>
          注册
        </button>

        <div className="bottom_info">
          <Link to="/login" className="login_text">
            已有账户? 返回登录页
          </Link>
        </div>
      </div>
    </div>
  );
};

export default RegisterScreen;
