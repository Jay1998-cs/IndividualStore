import React from "react";

// 订单详情页【需要防护，未登录用户 或者与订单下单用户不一致的，无法访问】
// 显示：订单号、收货地址、支付方式、订单信息(购买商品、单价、运费、总价)
const PaymentDetail = () => {
  return <div>PaymentDetail</div>;
};

export default PaymentDetail;
