import React, { useEffect, useState } from "react";
import MessagePromt from "../components/MessagePromt";

const UpdateUserPswForm = ({
  clickBtnHandler,
  userEmail,
  isUpdateOk,
  backendErrorMsg,
}) => {
  const [inputedEmail, setInputedEmail] = useState("");
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const successMsg = "用户密码已更新成功!";
  // console.log("isUpdateOk", isUpdateOk);

  // 更新成功，初始化页面内容
  useEffect(() => {
    if (isUpdateOk) {
      setInputedEmail("");
      setOldPassword("");
      setNewPassword("");
      setErrorMessage("");
    }
  }, [isUpdateOk]);

  // 邮箱输入事件
  const emailInputHandler = (e) => {
    setInputedEmail(e.target.value);
  };

  // 旧密码输入事件
  const oldPasswordInputHandler = (e) => {
    setOldPassword(e.target.value);
  };

  // 新密码输入事件
  const newPasswordInputHandler = (e) => {
    setNewPassword(e.target.value);
  };

  // 输入验证
  const checkInputed = (userEmail, inputedEmail, oldPassword, newPassword) => {
    let isValid = false;
    let message = "";
    if (!inputedEmail || !oldPassword || !newPassword) {
      isValid = false;
      message = "error: 输入不能为空!";
    } else if (inputedEmail !== userEmail) {
      isValid = false;
      message = "error: 邮箱验证失败!";
    } else {
      isValid = true;
      message = "";
    }

    return { isValid, message };
  };

  // 确认按钮单击事件
  const clickSubmitHandler = () => {
    // 初始化错误消息(清空历史错误消息，因为单击确认按钮时重新提交了新数据)
    setErrorMessage("");

    // 输入验证
    const { isValid, message } = checkInputed(
      userEmail,
      inputedEmail,
      oldPassword,
      newPassword
    );
    // console.log(userEmail, inputedEmail, oldPassword, newPassword);

    // 失败
    if (!isValid) {
      setErrorMessage(message);
      return;
    }

    // 成功，将传递数据由父组件处理、并初始化输入内容
    clickBtnHandler({ oldPassword, password: newPassword });
  };

  return (
    <div className="container flex-col-center">
      <div className="update-name-form ">
        <h3>请更新登录密码</h3>
        <div className="item">
          <label htmlFor="email" maxLength={24}>
            邮箱:
          </label>
          <input
            type="emial"
            id="email"
            value={inputedEmail}
            onChange={emailInputHandler}
          />
        </div>
        <div className="item">
          <label htmlFor="oldPassword">原密码:</label>
          <input
            type="password"
            id="oldPassword"
            maxLength={14}
            value={oldPassword}
            onChange={oldPasswordInputHandler}
          />
        </div>
        <div className="item">
          <label htmlFor="newPassword">新密码:</label>
          <input
            type="password"
            id="newPassword"
            placeholder="...1~14位,字母/数字..."
            maxLength={14}
            value={newPassword}
            onChange={newPasswordInputHandler}
          />
        </div>
        {(errorMessage || backendErrorMsg) && (
          <MessagePromt
            message={errorMessage || backendErrorMsg}
            isError={true}
          />
        )}
        {isUpdateOk && !errorMessage && !backendErrorMsg && (
          <MessagePromt message={successMsg} isError={false} />
        )}
        <button className="btn" onClick={clickSubmitHandler}>
          确认
        </button>
      </div>
    </div>
  );
};

export default UpdateUserPswForm;
