import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CalculationBox from "../components/CalculationBox";
import { CART_UPATE_ITEM_COUNT } from "../constants/cartConstants";
import { addORupdateCartAct } from "../actions/cartActions";
import { fixed2Number } from "../utils/utils";

const OrderScreen = ({ submitHandler }) => {
  const dispatch = useDispatch();

  const { cartItems } = useSelector((state) => state.cartReducer);
  const selectedItems = cartItems.filter((item) => item.isSelected);

  // 记录购买的产品数量、总价
  let totalCount = 0;
  let itemsPrice = 0;
  if (selectedItems.length > 0) {
    selectedItems.forEach((item) => {
      if (item.isSelected) {
        totalCount += item.count;
        itemsPrice += Number(item.count) * Number(item.price);
      }
    });
  }
  // 运费
  const shippingPrice = Number(itemsPrice) > 9.9 ? 0 : 6; // 默认0或6元
  // 总价 = 所有项目总价 + 运费
  const totalPrice = itemsPrice + shippingPrice; // 总金额，保留两位小数

  // 单击提交订单Button，传递待选择的待付款的项目信息
  const clickSubmitBtnHandler = () => {
    const itemsSelectedInfo = {
      orderItems: selectedItems,
      totalPrice: totalPrice,
      shippingPrice: shippingPrice,
    };
    submitHandler(itemsSelectedInfo);
  };

  // 购物车中某个产品的购买数量更新事件
  const countChangeHandler = (productId, count) => {
    dispatch(addORupdateCartAct(productId, count, CART_UPATE_ITEM_COUNT));
  };

  const CartItemListStyle = (
    <div className="item-container">
      {selectedItems.map((item, idx) => (
        <div key={idx} className="item-box">
          <img src={item.image} alt="item" />
          <div className="info">
            <div className="name">{item.name}</div>
            <div className="price">{item.price}</div>
          </div>
          <CalculationBox
            minVal={1}
            maxVal={item.countInStock}
            initCount={item.count}
            onChangeHandler={(count, productId = item.productId) => {
              countChangeHandler(productId, count);
            }}
          />
        </div>
      ))}
    </div>
  );

  // 购物车底部结算栏样式
  const paymentBarStyle = selectedItems.length > 0 && (
    <div className="payment-bar">
      <div className="selected-info">共{totalCount}件</div>
      <div className="amount-info">
        <span className="text">合计:</span>
        <span className="digit">{fixed2Number(totalPrice)}</span>
        <span className="symbol">￥</span>
      </div>
      <div className="payment-btn" onClick={clickSubmitBtnHandler}>
        提交订单
      </div>
    </div>
  );

  return (
    <div className="order-container">
      <h3 className="title">订单详情</h3>
      {CartItemListStyle}
      <div className="shipping-info">
        <span className="text">运费:</span>
        <span className="price">{fixed2Number(shippingPrice)}</span>
        <span className="symbol">￥</span>
      </div>
      {paymentBarStyle}
    </div>
  );
};

export default OrderScreen;
