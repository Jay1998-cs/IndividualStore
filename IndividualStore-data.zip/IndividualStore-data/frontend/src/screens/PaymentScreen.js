import React, { useEffect, useState } from "react";
import ShippingInfoScreen from "./ShippingInfoScreen";
import OrderScreen from "./OrderScreen";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { routePathDict } from "../config/config";
import { orderCeatedAct } from "../actions/orderActions";
import { replceItemsInCartAct } from "../actions/cartActions";
import { tipFunc } from "../utils/tip";
// import MessagePromt from "../components/MessagePromt";

const PaymentScreen = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { userInfo = {} } = useSelector((state) => state.userInfoReducer);
  const { cartItems = [] } = useSelector((state) => state.cartReducer);

  const [shippingInfo, setShippingInfo] = useState(null);

  // 未登录用户，或者购物车为空时，无法访问支付页，跳转到登录页
  // 【因为useSelector是异步的，且用户或购物车随时可能为null，故需要useEffect】
  useEffect(() => {
    if (!Object.keys(userInfo).length || !Object.keys(cartItems).length) {
      navigate(routePathDict.login);
    }
  }, [userInfo, cartItems, navigate]);

  // 接收shippingInfo即用户收件信息
  const receiveShippingInfo = (shippingInfo) => {
    setShippingInfo(shippingInfo);
    // console.log("确认收货信息: ", shippingInfo);
  };

  // 在购物车中，移除已提交到订单的项目 -> 等价于只留下未选购的项目(isSelected为false)
  const removeItemsSubmittedInCart = (orderItems = []) => {
    if (!orderItems.length) {
      return; // 订单不存在选购的项目，退出
    }
    const leftItemsInCart = cartItems.filter((item) => !item.isSelected); // 购物车剩余未选购的项目
    dispatch(replceItemsInCartAct(leftItemsInCart)); // 从购物车中移除这些产品
  };

  // 处理提交的订单
  const processOrder = async (order) => {
    // console.log("提交的订单: ", order);
    try {
      // 提交订单
      dispatch(orderCeatedAct(order));
      ///////////////////////// 支付处理
      tipFunc("【支付处理: 弹出二维码支付页面】 at 【PaymentScreen.js】");

      ///////////////////////// 支付完成处理【弹出支付完成提示框、跳转到对应订单详情页等】
      tipFunc("【支付完成提示、跳转到订单详情页等】 at 【PaymentScreen.js】");
      removeItemsSubmittedInCart(order.orderItems); // 购物车中移除已提交到订单的项目
      // navigate(routePathDict.home); // 暂时跳回主页、待改 -> 跳转到对应订单详情页
    } catch (error) {
      /////////////////////////订单提交失败
      console.error(error);
      tipFunc("【支付失败提示、跳转到订单待支付页等】 at 【PaymentScreen.js】");
    }
  };

  // 提交订单
  const submitOrderHandler = (itemsSelectedInfo) => {
    // 检查收件信息是否已录入
    if (!shippingInfo) {
      alert("error: 请填写收件信息!"); // 【修改成弹窗】
      return;
    }

    // 处理提交的订单，保存到store
    const order = {
      ...shippingInfo,
      ...itemsSelectedInfo,
    };
    processOrder(order);
  };

  return (
    <div className="payment-container">
      <ShippingInfoScreen confirmHandler={receiveShippingInfo} />
      <OrderScreen submitHandler={submitOrderHandler} />
    </div>
  );
};

export default PaymentScreen;
