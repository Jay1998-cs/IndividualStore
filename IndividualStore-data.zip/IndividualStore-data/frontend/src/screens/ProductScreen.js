import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import Rating from "../components/Rating";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { addORupdateCartAct } from "../actions/cartActions";
import CalculationBox from "../components/CalculationBox";
// import MessagePromt from "../components/MessagePromt";

const ProductScreen = () => {
  let [product, setProduct] = useState({});

  const dispatch = useDispatch();

  const countInputRef = useRef(null); // 购买数量输入标签(input)的引用

  const { id: productId } = useParams();
  const prodcutURL = `/api/products/${productId}`;

  // 获取当前URL显示的产品
  const { products } = useSelector((state) => state.productListReducer);
  const product_cache = products.find((product) => product._id === productId);

  // 库存、最少可购买数量、最大可购买数量
  const stock = product.countInStock || 0;
  const minCount = stock > 0 ? 1 : 0;
  const maxCount = stock;

  // 获取当前product数据，若store中已有则直接获取，否则请求后端数据库
  useEffect(() => {
    const fetchProduct = async () => {
      const { data } = await axios.get(prodcutURL);
      setProduct(data);
    };
    try {
      // 若store已缓存当前product数据则直接获取，否则请求后端数据
      if (!product_cache) {
        fetchProduct();
      } else {
        setProduct(product_cache);
      }
    } catch (error) {
      console.log(error);
    }
  }, [product_cache, prodcutURL]);

  // 添加当前product到购物车
  const addToCartHandler = () => {
    const buyCount = Number(countInputRef.current.value);
    // console.log(buyCount);

    dispatch(addORupdateCartAct(productId, buyCount)); // 触发购物车action,更新数据
  };

  // 无当前产品数据
  if (!product) {
    return <h3>Not Found Product</h3>;
  }

  // 是否有库存样式，有库存则显式添加到购物车按钮，否则显式提示文本
  const stockStyle =
    stock > 0 ? (
      <button className="add-btn" onClick={addToCartHandler}>
        添加到购物车
      </button>
    ) : (
      <p style={{ color: "gray" }}>状态: 无库存</p>
    );

  return (
    <div className="product-detail-container">
      <div className="product-img">
        <img src={product.image} alt="img" />
      </div>

      <div className="product-info">
        <h3>{product.name}</h3>

        <Rating
          nums={5}
          value={product.rating}
          text={`${product.numReviews}条评价`}
        />

        <div className="product-sale">
          <p>价格: ￥{product.price}</p>
          {stock > 0 && (
            <>
              <div>库存: {product.countInStock} </div>
              <CalculationBox
                minVal={minCount}
                maxVal={maxCount}
                ref={countInputRef}
              />
            </>
          )}
          {stockStyle}
        </div>

        <div className="desc">简介: {product.description}</div>
      </div>
    </div>
  );
};

export default ProductScreen;

// fetch product detail by useEffect Hook:
// const prodcutURL = `/api/products/${id}`;
// const [product, setProduct] = useState({});
// useEffect(() => {
//   // fetch single product data
//   const fetchProduct = async () => {
//     const { data } = await axios.get(prodcutURL);
//     setProduct(data);
//   };
//   try {
//     fetchProduct();
//   } catch (error) {
//     console.log(error);
//   }
// }, [prodcutURL]);
