import React from "react";

const UserOrderScreen = () => {
  return <div>UserOrderScreen</div>;
};

export default UserOrderScreen;
