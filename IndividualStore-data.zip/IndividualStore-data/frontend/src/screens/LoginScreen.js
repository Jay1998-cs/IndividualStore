import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { userLoginAct } from "../actions/userActions";
import { routePathDict } from "../config/config";

const LoginScreen = () => {
  const userInputedInitialState = { email: "", password: "" };
  const [userInputed, setUserInputed] = useState(userInputedInitialState);
  const { email, password } = userInputed;
  // console.log(userInputed);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  // 获取可能已登录的用户信息 xxxxxxxxx【若用户已登录则？？？】
  const {
    loading = false,
    error = "",
    userInfo = {},
  } = useSelector((state) => state.userInfoReducer);
  const userId = userInfo._id;
  // console.log("userInfo: ", userInfo, loading, error, userId);

  // 处理已登录用户
  useEffect(() => {
    if (userId && Object.keys(userInfo).length) {
      // 页面重定向，默认跳转到首页 xxxxx
      const redirectUrl = window.location.search
        ? window.location.search.split[1]
        : "/";

      navigate(redirectUrl);
      // console.log(window.location.search); xxxxx
    }
  }, [userId, userInfo, navigate]);

  // 邮箱输入事件
  const emailInputHandler = (e) => {
    setUserInputed((preState) => ({ ...preState, email: e.target.value }));
  };

  // 密码输入事件
  const passwordInputHandler = (e) => {
    setUserInputed((preState) => ({ ...preState, password: e.target.value }));
  };

  // 单击登录按钮
  const clickLoginBtnHandler = (e) => {
    e.preventDefault();

    // 处理用户登录(验证输入是否合法:长度、是否为邮箱、合法字符)
    if (email && password) {
      // 数据更新到store
      dispatch(userLoginAct(email, password));
    } else {
      // 登录失败——[前端]验证输入有误，弹出提示框 xxxxxxxxxxxxxxx
      alert("失败: 请输入邮箱和密码!");
    }
  };

  // 单击用户注册文本
  // const clickRegisterBtnHandler = () => {
  //   alert("切换当前视图为“用户注册”页面");
  // };

  return (
    <div className="user_form_container">
      <div className="user_form_content login_page">
        <h3>邮箱登录</h3>
        <div className="userInfo_form">
          <label htmlFor="email">邮箱:</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={emailInputHandler}
          />

          <label htmlFor="password">密码:</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={passwordInputHandler}
          />
          {error && (
            <div className="errorMessage">邮箱或密码有误,请重新输入.</div>
          )}
          {loading && <div className="tip">...正在登录...</div>}
        </div>
        <button className="submit_btn" onClick={clickLoginBtnHandler}>
          确认
        </button>
        <div className="bottom_info">
          <span
            className="forget_psw"
            onClick={() => {
              alert('切换到"找回密码"页面');
            }}
          >
            忘记密码?
          </span>
          <Link to={routePathDict.register} className="register_text">
            新用户账号注册
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
