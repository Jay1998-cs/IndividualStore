import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import CalculationBox from "../components/CalculationBox";
import { useDispatch } from "react-redux";
import { routePathDict } from "../config/config";
import { fixed2Number } from "../utils/utils";
import { CART_UPATE_ITEM_COUNT } from "../constants/cartConstants";
import {
  addORupdateCartAct,
  removeFromCartAct,
  updateItemIsSelectedAct,
} from "../actions/cartActions";
import { tipFunc } from "../utils/tip";

const CartScreen = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // 从store获取可能已登录的用户id，未登录的用户调整到登录页
  const { userInfo = {} } = useSelector((state) => state.userInfoReducer);
  const userId = userInfo._id;
  useEffect(() => {
    if (!userId) {
      navigate(routePathDict.login);
    }
  }, [userId, navigate]);

  // 从store获取购物车中的所有产品数据
  const { cartItems = [] } = useSelector((state) => state.cartReducer);
  const isAllSelected = cartItems.every((item) => item.isSelected); // 是否全选购物车中的项目

  // 记录勾选的项目的信息
  let totalSelctedCount = 0; // 勾选的项目数量
  let totalPrice = 0; // 勾选的所有项目的总价
  let cartSelectedItems = []; // 选择的项目数组
  if (cartItems.length > 0) {
    cartItems.forEach((item) => {
      if (item.isSelected) {
        ++totalSelctedCount;
        totalPrice += Number(item.count) * Number(item.price);
        cartSelectedItems.push(item);
      }
    });
  }
  totalPrice = fixed2Number(totalPrice); // 保留两位小数
  // console.log("选购的产品: ", cartSelectedItems);

  // 单击结算Button
  const clickPaymentBtnHandler = () => {
    // 若未选购物品，则【弹窗提示】xxxxxxxxxxxxxxxxxx
    if (!cartSelectedItems.length) {
      tipFunc("【弹窗提示: 未选购物品~】 at 【CartScreen.js】");
      alert("请选购物品~");
      return;
    }
    // 跳转到“订单(支付)”页，isSlected为true的项目为待支付项
    navigate(routePathDict.payment);
  };

  // 单击移除产品Button
  const clickRemoveBtnHandler = (productId) => {
    dispatch(removeFromCartAct(productId));
  };

  // 购物车中某个产品的购买数量更新事件
  const countChangeHandler = (productId, count) => {
    dispatch(addORupdateCartAct(productId, count, CART_UPATE_ITEM_COUNT));
  };

  // 勾选某种产品
  const selectItemHandler = (productId) => {
    dispatch(updateItemIsSelectedAct(productId));
  };

  // 单击全选按钮：全选或全部取消勾选
  const selectAllItemsHandler = async () => {
    const isSelectedAll = isAllSelected ? false : true; // toggle状态(true <-> false)
    dispatch(updateItemIsSelectedAct(null, isSelectedAll, !isSelectedAll));
  };

  // 购物车内容样式(项目列表)
  const itemListStyle =
    cartItems.length > 0 &&
    cartItems.map((item, idx) => (
      <div className="cartItem-container" key={idx}>
        <i
          className={`icon-select fa-sharp fa-regular fa-circle-check ${
            item.isSelected && " active"
          }`}
          onClick={() => {
            selectItemHandler(item.productId);
          }}
        />
        <img src={item.image} alt="" />
        <div className="description">
          <p className="name">{item.name}</p>
          <p className="price">￥{item.price}</p>
        </div>
        <CalculationBox
          minVal={1}
          maxVal={item.countInStock}
          initCount={item.count}
          onChangeHandler={(count, productId = item.productId) => {
            countChangeHandler(productId, count);
          }}
        />
        <span
          className="remove"
          onClick={() => {
            clickRemoveBtnHandler(item.productId);
          }}
        >
          <span className="line"></span>
        </span>
      </div>
    ));

  // 购物车底部结算栏样式
  const paymentBarStyle = cartItems.length > 0 && (
    <div className="payment-bar">
      <div className="select-box">
        <i
          className={`icon-select fa-sharp fa-regular fa-circle-check ${
            isAllSelected && " active"
          }`}
          onClick={selectAllItemsHandler}
        />
        <span>全选</span>
      </div>
      <div className="selected-info">已选{totalSelctedCount}件</div>
      <div className="amount-info">
        <span className="text">总价:</span>
        <span className="digit">{totalPrice}</span>
        <span className="symbol">￥</span>
      </div>
      <div className="payment-btn" onClick={clickPaymentBtnHandler}>
        <span>结</span>
        <span>算</span>
      </div>
    </div>
  );

  return cartItems.length > 0 ? (
    <div className="cart-container">
      {itemListStyle}
      {paymentBarStyle}
    </div>
  ) : (
    <div className="tip">购物车为空,赶紧选购吧~</div>
  );
};

export default CartScreen;
