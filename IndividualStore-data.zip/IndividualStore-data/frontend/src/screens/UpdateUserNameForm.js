import React, { useEffect, useState } from "react";
import MessagePromt from "../components/MessagePromt";

const UpdateUserNameForm = ({
  userName,
  clickBtnHandler,
  isUpdateOk,
  backendErrorMsg,
}) => {
  const [newName, setNewName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // 更新成功，初始化页面内容
  useEffect(() => {
    if (isUpdateOk) {
      setErrorMessage("");
      setNewName("");
    }
  }, [isUpdateOk]);

  // 新用户名输入事件
  const newNameInputHandler = (e) => {
    if (e.target.value.length >= 14) {
      return;
    }
    setNewName(e.target.value);
  };

  // 确认按钮单击事件
  const clickSubmitHandler = () => {
    // 初始化、清空历史错误消息
    setErrorMessage("");
    // 用户名简单验证
    if (newName.length < 1 || newName.length > 14) {
      setErrorMessage("error: 用户名长度必需为1~14");
      return;
    }
    // 更新用户姓名
    clickBtnHandler({ name: newName });
  };

  return (
    <div className="container flex-col-center">
      <div className="update-name-form ">
        <h3>请设置新用户名</h3>
        <div className="item">
          <label htmlFor="oldName">用户名:</label>
          <input
            type="text"
            id="oldName"
            readOnly="readOnly"
            disabled="disabled"
            value={userName}
          />
        </div>
        <div className="item">
          <label htmlFor="newName">新名称:</label>
          <input
            type="text"
            id="newName"
            value={newName}
            placeholder="...1~14位,字母/数字..."
            maxLength={14}
            onChange={newNameInputHandler}
          />
        </div>
        {(errorMessage || backendErrorMsg) && (
          <MessagePromt
            message={errorMessage || backendErrorMsg}
            isError={true}
          />
        )}
        {isUpdateOk && !errorMessage && !backendErrorMsg && (
          <MessagePromt message={"用户名更新成功!"} />
        )}
        <button className="btn" onClick={clickSubmitHandler}>
          确认
        </button>
      </div>
    </div>
  );
};

export default UpdateUserNameForm;
