import React, { useState } from "react";
import {
  checkUserName,
  checkPhoneNumber,
  checkShippingAdress,
} from "../utils/utils";
import MessagePromt from "../components/MessagePromt";

const ShippingInfoScreen = ({ confirmHandler }) => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [shippingAddress, setShippingAddress] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [isSuccess, setIsSuccess] = useState(false);
  const successMessage = "信息已保存";
  // console.log(name, phone, address);

  // 保存输入数据
  const nameInputHandler = (e) => {
    setName(e.target.value);
  };
  const phoneInputHandler = (e) => {
    setPhone(e.target.value + "");
  };
  const addressInputHandler = (e) => {
    setShippingAddress(e.target.value);
  };

  // 检查、处理输入数据
  const processInputs = () => {
    try {
      if (
        // 输入验证
        checkUserName(name) &&
        checkPhoneNumber(phone) &&
        checkShippingAdress(shippingAddress)
      ) {
        ///////////////////////////////////////////////////
        // 存储输入数据【待修改】
        // console.log("确认数据: ", { name, phone, address });
        confirmHandler({ name, phone, shippingAddress });

        // 初始化状态
        setErrorMessage("");
        setIsSuccess(true);
      }
    } catch (error) {
      console.error(error.message);
      // 更新状态
      setErrorMessage(error.message);
      setIsSuccess(false);
    }
  };

  // 修改按钮单击事件
  const clickModifyBtnHandler = (e) => {
    e.preventDefault();
    setIsSuccess(false);
    setErrorMessage("");
  };

  // 确认按钮单击事件
  const clickSubmitBtnHandler = (e) => {
    e.preventDefault();
    // console.log("提交数据: ", { name, phone, address });
    processInputs(); // 处理用户填写、提交的数据
  };

  // 姓名输入组件
  const nameComponent = (
    <div className="name-box item">
      <label htmlFor="name">收货人</label>
      <input
        id="name"
        type="text"
        value={name}
        disabled={isSuccess ? "disabled" : ""}
        placeholder="名字(不超过10个字)"
        maxLength={10}
        onChange={nameInputHandler}
      />
    </div>
  );

  // 手机号输入组件
  const phoneComponent = (
    <div className="phone-box item">
      <label htmlFor="phone">手机号码</label>
      <input
        id="phone"
        type="text"
        value={phone}
        disabled={isSuccess ? "disabled" : ""}
        placeholder="+86手机号(11位)"
        maxLength={11}
        onChange={phoneInputHandler}
      />
    </div>
  );

  // 地址输入组件
  const adressComponent = (
    <div className="phone-box item">
      <label htmlFor="address">详细地址</label>
      <textarea
        name="address"
        id="address"
        value={shippingAddress}
        disabled={isSuccess ? "disabled" : ""}
        cols="20"
        rows="3"
        placeholder="省份/市区/城镇/小区/楼栋(不超过50个字)"
        maxLength={50}
        onChange={addressInputHandler}
      ></textarea>
    </div>
  );

  return (
    <div className="shippingInfo-form">
      <h3 className="title">收货信息</h3>

      <div className="receiving-info-form">
        {nameComponent}
        {phoneComponent}
        {adressComponent}
      </div>

      {errorMessage && <MessagePromt message={errorMessage} isError={true} />}
      {isSuccess && <MessagePromt message={successMessage} isError={false} />}

      <div className="bottom-btns">
        <button className="btn" onClick={clickModifyBtnHandler}>
          修改
        </button>
        <button
          className={`btn ${isSuccess && "disabled"}`}
          onClick={clickSubmitBtnHandler}
        >
          确认
        </button>
      </div>
    </div>
  );
};

export default ShippingInfoScreen;
