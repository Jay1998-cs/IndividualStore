import React, { useEffect, useState } from "react";
import MessagePromt from "../components/MessagePromt";

const UpdateUserEmailForm = ({
  userEmail,
  clickBtnHandler,
  isUpdateOk,
  backendErrorMsg,
}) => {
  const [oldEmail, setOldEmail] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // 更新成功，初始化页面内容
  useEffect(() => {
    if (isUpdateOk) {
      setErrorMessage("");
      setOldEmail("");
      setNewEmail("");
    }
  }, [isUpdateOk]);

  // 旧邮箱输入事件
  const oldEmailInputHandler = (e) => {
    setOldEmail(e.target.value);
  };

  // 新邮箱输入事件
  const newEmailInputHandler = (e) => {
    setNewEmail(e.target.value);
  };

  // 确认按钮单击事件
  const clickSubmitHandler = () => {
    // 初始化错误提示信息(清空历史错误消息)
    setErrorMessage("");

    // console.log(oldEmail, newEmail, userEmail);
    if (!oldEmail || !newEmail) {
      setErrorMessage("error: 输入内容不能为空!");
      return;
    }

    // 验证输入的原邮箱是否与存储数据的一致
    if (oldEmail !== userEmail) {
      setErrorMessage("error: 验证失败，原邮箱有误!");
      return;
    }

    // 验证输入的原邮箱是否与存储数据的一致
    if (newEmail === userEmail) {
      setErrorMessage("error: 邮箱相同!");
      return;
    }

    // 更新userinfo
    clickBtnHandler({ email: newEmail });
  };

  return (
    <div className="container flex-col-center">
      <div className="update-name-form ">
        <h3>请更新邮箱</h3>
        <div className="item">
          <label htmlFor="oldEmail">原邮箱:</label>
          <input
            type="email"
            id="oldEmail"
            maxLength={24}
            value={oldEmail}
            onChange={oldEmailInputHandler}
          />
        </div>
        <div className="item">
          <label htmlFor="newEmail">新邮箱:</label>
          <input
            type="email"
            id="newEmail"
            maxLength={24}
            value={newEmail}
            onChange={newEmailInputHandler}
          />
        </div>
        {(errorMessage || backendErrorMsg) && (
          <MessagePromt
            message={errorMessage || backendErrorMsg}
            isError={true}
          />
        )}
        {isUpdateOk && !errorMessage && !backendErrorMsg && (
          <MessagePromt message={"邮箱更新成功!"} isError={false} />
        )}
        <button className="btn" onClick={clickSubmitHandler}>
          确认
        </button>
      </div>
    </div>
  );
};

export default UpdateUserEmailForm;
