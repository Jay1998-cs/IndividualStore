import React from "react";
import Rating from "./Rating";
import { Link } from "react-router-dom";

const Product = ({ product }) => {
  const prodcutDetailURL = `/products/${product._id}`;

  // render
  return (
    <div className="card product-container">
      <div className="img-wrapper">
        <Link to={prodcutDetailURL}>
          <img src={product.image} alt="img" />
        </Link>
      </div>

      <div className="info-wrapper">
        <div className="name">
          <Link to={prodcutDetailURL}>{product.name}</Link>
        </div>

        <Rating
          nums={5}
          value={product.rating}
          text={`${product.numReviews}条评论`}
        />

        <div className="price">￥{product.price}</div>
      </div>
    </div>
  );
};

export default Product;
