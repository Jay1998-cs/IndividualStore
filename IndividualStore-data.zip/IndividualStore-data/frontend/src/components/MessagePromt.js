import React, { useEffect, useRef } from "react";
import { COLORS } from "../constants/colors";

const MessagePromt = ({ message, bgColor, isError }) => {
  const ref = useRef(null);

  // 设置提示内容的背景色
  useEffect(() => {
    if (ref.current) {
      if (bgColor) {
        ref.current.style.backgroundColor = bgColor;
      } else if (isError) {
        ref.current.style.backgroundColor = COLORS.LIGHT_RED;
      } else {
        ref.current.style.backgroundColor = COLORS.GREEN;
      }
    }
  }, [isError, bgColor]);

  return (
    <div className="message-prompt" ref={ref}>
      {message}
    </div>
  );
};

export default MessagePromt;
