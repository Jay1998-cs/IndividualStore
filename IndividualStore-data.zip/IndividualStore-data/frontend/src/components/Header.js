import React, { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { userLogoutAct } from "../actions/userActions";

const Header = () => {
  const optionMenuRef = useRef(null);
  const countRef = useRef(null);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { userInfo } = useSelector((state) => state.userInfoReducer);
  const { name = "Login" } = userInfo || {};
  const isLogin = !!userInfo && Object.keys(userInfo).length;
  const { isAdmin = false } = userInfo;

  const { cartItems } = useSelector((state) => state.cartReducer);

  // 更新选购数量
  useEffect(() => {
    if (countRef.current && cartItems.length) {
      countRef.current.innerHTML = cartItems.length;
    } else {
      countRef.current.innerHTML = "";
    }
  }, [cartItems.length]);

  // 单击“退出登录”选项，注销用户、重定向到主页
  const clickLogoutHandler = () => {
    dispatch(userLogoutAct());
    navigate("/");
  };

  // 单击“个人中心”选项，重定向到对应页面
  const clickDetailHandler = () => {
    navigate("/profile");
  };

  // 单击“订单管理”选项
  const clickManageHandler = () => {
    alert("订单管理");
  };

  // 下拉框选项数据
  const options = [
    { desc: "退出登录", key: "logout", clickHandler: clickLogoutHandler },
    { desc: "个人中心", key: "detail", clickHandler: clickDetailHandler },
    isAdmin && {
      desc: "订单管理",
      key: "order",
      clickHandler: clickManageHandler,
    },
  ];

  // 鼠标移入用户区，显式下拉框
  const enterOptionMenuHandler = () => {
    optionMenuRef.current.classList.remove("hidden");
    optionMenuRef.current.classList.add("show");
  };

  // 鼠标移出用户区，隐藏下拉框
  const leaveOptionMenuHandler = () => {
    optionMenuRef.current.classList.remove("show");
    optionMenuRef.current.classList.add("hidden");
  };

  return (
    <header id="header">
      <Link to="/">
        <div className="item">
          <i className="fa-solid fa-house"></i>
          <span>Home</span>
        </div>
      </Link>
      <div id="container-right">
        <Link to="/cart">
          <div className="item">
            <span ref={countRef} className="cart-item-count"></span>
            <i className="fa-solid fa-cart-shopping"></i>
            <span>CART</span>
          </div>
        </Link>
        {isLogin ? (
          <div
            className="item"
            onMouseEnter={enterOptionMenuHandler}
            onMouseLeave={leaveOptionMenuHandler}
          >
            <i className="fa-solid fa-user"></i>
            <div className="userInfo">
              {name}
              <i className="fa-solid fa-caret-down"></i>
              <div className="drop_options_menu hidden" ref={optionMenuRef}>
                {options.map((option) => (
                  <div
                    className="option"
                    key={option.key}
                    onClick={option.clickHandler}
                  >
                    {option.desc}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <Link to="/login">
            <div className="item">
              <i className="fa-solid fa-user"></i>
              <span>{name}</span>
            </div>
          </Link>
        )}
      </div>
    </header>
  );
};

export default Header;
