import React from "react";
import CalculationBox from "./CalculationBox";
import { useDispatch } from "react-redux";
import { CART_UPATE_ITEM_COUNT } from "../constants/cartConstants";
import { addORupdateCartAct, removeFromCartAct } from "../actions/cartActions";

const CartItemList = ({ cartItems }) => {
  const dispatch = useDispatch();

  // 单击移除产品Button
  const clickRemoveBtnHandler = (productId) => {
    dispatch(removeFromCartAct(productId));
  };

  // 购物车中某个产品的购买数量更新事件
  const countChangeHandler = (productId, count) => {
    // console.log(productId, "update count: ", count);
    dispatch(addORupdateCartAct(productId, count, CART_UPATE_ITEM_COUNT));
  };

  // 购物车中的所有产品的样式
  const itemListStyle =
    cartItems.length > 0 &&
    cartItems.map((item, idx) => (
      <div className="cartItem-container" key={idx}>
        <i className="icon-select fa-sharp fa-regular fa-circle-check" />
        <img src={item.image} alt="" />
        <div className="description">
          <p className="name">{item.name}</p>
          <p className="price">￥{item.price}</p>
        </div>

        <CalculationBox
          minVal={1}
          maxVal={item.countInStock}
          initCount={item.count}
          onChangeHandler={(count, productId = item.productId) => {
            countChangeHandler(productId, count);
          }}
        />

        <span
          className="remove"
          onClick={() => {
            clickRemoveBtnHandler(item.productId);
          }}
        >
          <span className="line"></span>
        </span>
      </div>
    ));

  return <div className="cart-container">{itemListStyle}</div>;
};

export default CartItemList;
