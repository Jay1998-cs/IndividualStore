import React, { forwardRef, useState } from "react";

const CalculationBox = forwardRef(
  ({ minVal = 1, maxVal = 5, initCount = 1, onChangeHandler = null }, ref) => {
    // 记录购物车页面中某产品的购买数量，初始值为历史购物车中该产品的购买量
    const [countInputed, setCountInputed] = useState(initCount);
    // console.log("countInputed: ", countInputed);

    const onCountChangeHandler =
      typeof onChangeHandler === "function" ? onChangeHandler : () => {};

    // 单击-minVal按钮，数量减一
    const clickMinusBtnHandler = (productId) => {
      setCountInputed((preState) => {
        if (preState > minVal) {
          onCountChangeHandler(preState - 1); ////////////
          return preState - 1;
        } else {
          console.error(`error: 选购数量至少为${minVal}`);
          return minVal;
        }
      });
    };

    // 单击+1按钮，数量加一
    const clickPlusBtnHandler = (productId) => {
      setCountInputed((preState) => {
        if (preState < maxVal) {
          onCountChangeHandler(preState + 1); ////////////

          return preState + 1;
        } else {
          console.error(`error: 最多选购${maxVal}件产品`);
          return maxVal;
        }
      });
    };

    // 数量输入事件
    const countChangeHandler = (e) => {
      // 获取输入
      let inputValue = Number(e.target.value) || 1; // 【默认为string类型】

      // 验证输入：不能超过设置的最小最大值
      if (inputValue < minVal) {
        // 低于合法值
        inputValue = minVal;
        console.error("error: 购买数量至少为1");
      }
      if (inputValue > maxVal) {
        // 高于合法值
        inputValue = maxVal;
        console.error(`error: 最多购买${maxVal}件产品`);
      }

      // 更新数量count状态值
      setCountInputed(inputValue);

      // 触发父组件函数，处理数量count更新
      onCountChangeHandler(inputValue); ////////////
    };

    // 鼠标走数量输入框时使其失去焦点
    // const leaveInputHandler = (e) => {
    //   e.target.blur();
    // };

    return (
      <div className="calculation-box">
        <i
          className={`fa-sharp fa-solid fa-minus minus-icon ${
            countInputed <= minVal && "disabled"
          }`}
          onClick={clickMinusBtnHandler}
        ></i>
        <input
          type="number"
          className="count-input"
          ref={ref}
          value={countInputed}
          minLength={1}
          maxLength={maxVal}
          onChange={countChangeHandler}
          // onMouseLeave={leaveInputHandler}
        ></input>
        <i
          className={`fa-sharp fa-solid fa-plus plus-icon ${
            countInputed >= maxVal && "disabled"
          }`}
          onClick={clickPlusBtnHandler}
        ></i>
      </div>
    );
  }
);

export default CalculationBox;
