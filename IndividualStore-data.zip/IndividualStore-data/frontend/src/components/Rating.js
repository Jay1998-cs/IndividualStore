import React from "react";
import propTypes from "prop-types";

const Rating = ({ nums, value, text, color }) => {
  return (
    <div className="rating">
      {new Array(nums).fill(0).map((val, idx) => (
        <span key={idx}>
          <i
            className={
              value >= idx + 1
                ? "fa-solid fa-star"
                : value >= idx + 0.5
                ? "fa-regular fa-star-half-stroke"
                : "fa-regular fa-star"
            }
            style={{ color }}
          ></i>
        </span>
      ))}
      <span className="comment-info">{text && text}</span>
    </div>
  );
};

// porp类型
Rating.propTypes = {
  nums: propTypes.number.isRequired,
  value: propTypes.number,
  text: propTypes.string,
  color: propTypes.string,
};

// prop默认值
Rating.defaultProps = {
  color: "#f8e825",
};

export default Rating;
