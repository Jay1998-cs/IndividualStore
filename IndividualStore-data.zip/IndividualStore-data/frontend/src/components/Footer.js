import React from "react";

const Footer = () => {
  return (
    <footer id="footer">
      <span>CopyRight &copy; Individual Store by @LiJie</span>
    </footer>
  );
};

export default Footer;
