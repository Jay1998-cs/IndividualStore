import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Product from "./Product";
import { getProductListAct } from "../actions/productActions";

const ProductList = () => {
  const dispatch = useDispatch();
  const {
    loading = true,
    error = null,
    products = [],
  } = useSelector((state) => state.productListReducer);

  // [优化]只有首次加载 或者 展示的产品存在更新时 才重新获取数据
  useEffect(() => {
    dispatch(getProductListAct());
  }, [dispatch]);

  return loading ? (
    <h2>Loading...</h2>
  ) : error ? (
    <h2>Error: {error.message || "Loading Failed.."}</h2>
  ) : (
    <div className="products">
      {products.map((product) => (
        <Product key={product._id} product={product}></Product>
      ))}
    </div>
  );
};

export default ProductList;

// fetch data by useEffect Hook:
// const [products, setProducts] = useState([]);
// useEffect(() => {
//   const fetchProducts = async () => {
//     const { data } = await axios.get("/api/products");
//     setProducts(data);
//   };
//   try {
//     fetchProducts();
//   } catch (error) {
//     console.error(error);
//   }
// }, []);
