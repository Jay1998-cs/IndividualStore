import {
  CART_ADD_OR_UPDATE_ITEM,
  CART_UPATE_ITEM_COUNT,
  CART_CLEAR_ALL_ITEMS,
  CART_REMOVE_ITEM,
  CART_SAVE_SHIPPING_ADDRESS,
  CART_SAVE_PAYMENT_METHOD,
  CART_UPDATE_ITEM_SELECTED_STATE,
  CART_REPLACE_ITEMS,
} from "../constants/cartConstants";

// 购物车状态
export const cartReducer = (state = { cartItems: [] }, action) => {
  switch (action.type) {
    // 添加项目到购物车，或更新购物车中的已存在项目的选购数量count
    case CART_ADD_OR_UPDATE_ITEM:
      // 获取添加到购物车的某个项目，并查找购物车是否已存在该项目
      const addedItem = action.payload;
      const existedItem = state.cartItems.find(
        (item) => item.productId === addedItem.productId
      );
      // console.log("existedItem:", existedItem);

      // 若购物车已存在该项目，则更新其数量，否则添加该项目到购物车
      if (existedItem) {
        // console.log("已存在在产品:", existedItem.productId);
        const updatedItem = {
          ...existedItem,
          count: existedItem.count + addedItem.count, // 增加或减少购买数量(count可负)
        };
        return {
          ...state,
          cartItems: state.cartItems.map((item) =>
            item.productId === existedItem.productId ? updatedItem : item
          ),
        };
      } else {
        // 购物车中无该项目，直接将其添加到购物车项目数组
        state.cartItems.push(addedItem);
        return {
          ...state, // 【更新对象引用，否则无法检测到其变化】
        };
      }

    // 更新某个项目的选购数量count
    case CART_UPATE_ITEM_COUNT:
      // 待更新的某个商品对象
      const updateProduct = action.payload;
      // 覆盖(更新)原有产品的数据
      return {
        ...state,
        cartItems: state.cartItems.map((item) =>
          item.productId !== updateProduct.productId
            ? item
            : {
                ...item,
                count: updateProduct.count,
              }
        ),
      };

    // 移除购物车中的某个项目
    case CART_REMOVE_ITEM:
      return {
        ...state,
        cartItems: state.cartItems.filter(
          (item) => item.productId !== action.payload.productId
        ),
      };

    // 替换(更新)购物车中的项目
    case CART_REPLACE_ITEMS:
      return {
        ...state,
        cartItems: action.payload.newCartItems,
      };

    // 更新购物车中的项目的勾选状态
    case CART_UPDATE_ITEM_SELECTED_STATE:
      const { productId, isSelectedAll, isCancelAll } = action.payload;
      const cartItems = state.cartItems;
      // 全选
      if (isSelectedAll) {
        cartItems.forEach((item) => {
          item.isSelected = true;
        });
      }
      // 全取消
      if (isCancelAll) {
        cartItems.forEach((item) => {
          item.isSelected = false;
        });
      }
      // 勾选某个项目,toggle其勾选状态
      if (productId && !isSelectedAll && !isCancelAll) {
        cartItems.forEach((item) => {
          if (item.productId === productId) {
            item.isSelected = !item.isSelected;
          }
        });
      }
      return { ...state, cartItems: cartItems };
    case CART_CLEAR_ALL_ITEMS:
      return state;
    case CART_SAVE_SHIPPING_ADDRESS:
      return state;
    case CART_SAVE_PAYMENT_METHOD:
      return state;
    default:
      return state;
  }
};
