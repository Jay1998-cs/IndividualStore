import { USER_CONSTANTS as TYPE } from "../constants/userConstants";

// 用户登录
export const userInfoReducer = (state = {}, action) => {
  switch (action.type) {
    case TYPE.USER_LOGIN_REQUEST:
      return { loading: true, userInfo: {} };
    case TYPE.USER_LOGIN_SUCCESS:
      return {
        // loading: false,
        userInfo: action.payload.userInfo,
      };
    case TYPE.USER_LOGIN_FAIL:
      console.error("[error]: ", action.payload, " at userLoginReducer");
      return {
        loading: false,
        error: action.payload,
        userInfo: {},
      };
    case TYPE.USER_LOGOUT:
      return { userInfo: {} };
    default:
      return state;
  }
};

// 用户注册(@已废弃)
export const userRegisterReducer = (state = {}, action) => {
  switch (action.type) {
    case TYPE.USER_REGISTER_REQUEST:
      return { loading: true, isRegisted: false };
    case TYPE.USER_REGISTER_SUCCESS:
      return {
        loading: false,
        isRegisted: true,
        // userInfo: action.payload.userInfo,
      };
    case TYPE.USER_REGISTER_FAIL:
      console.error("[error]: ", action.payload, " at userRegisterReducer");
      return {
        loading: false,
        error: action.payload,
        isRegisted: false,
      };
    case TYPE.USER_REGISTER_DONE:
      return {};
    default:
      return state;
  }
};
