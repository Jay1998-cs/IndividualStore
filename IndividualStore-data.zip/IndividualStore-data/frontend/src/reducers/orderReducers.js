import { ORDER_ACT_TYPES } from "../constants/orderConstants";

export const orderReducer = (state = {}, action) => {
  switch (action.type) {
    case ORDER_ACT_TYPES.ORDER_CREATED_REQUEST:
      return { ...state, loading: true, isSuccess: false };
    case ORDER_ACT_TYPES.ORDER_CREATED_SUCCESS:
      return {
        orderSubmitted: action.payload,
        loading: false,
        isSuccess: true,
      };
    case ORDER_ACT_TYPES.ORDER_CREATED_FAIL:
      return { error: action.payload, loading: false, isSuccess: false };
    default:
      return state;
  }
};
