import { createBrowserRouter } from "react-router-dom";
import HomeScreen from "../screens/HomeScreen";
import ProductScreen from "../screens/ProductScreen";
import ProductList from "../components/ProductList";
import CartScreen from "../screens/CartScreen";
import LoginScreen from "../screens/LoginScreen";
import RegisterScreen from "../screens/RegisterScreen";
import ProfileScreen from "../screens/ProfileScreen";
import { routePathDict } from "../config/config";
import PaymentScreen from "../screens/PaymentScreen";
import PaymentDetail from "../screens/PaymentDetail";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <HomeScreen />,
    children: [
      {
        path: "/",
        element: <ProductList />,
      },
      {
        path: routePathDict.cart,
        element: <CartScreen />,
      },
      {
        path: routePathDict.payment,
        element: <PaymentScreen />,
      },
      {
        path: `${routePathDict.payment}/:id`,
        element: <PaymentDetail />,
      },
      {
        path: routePathDict.login,
        element: <LoginScreen />,
      },
      {
        path: routePathDict.register,
        element: <RegisterScreen />,
      },
      {
        path: routePathDict.profile,
        element: <ProfileScreen />,
      },
      {
        path: routePathDict.product_detail,
        element: <ProductScreen />,
      },
    ],
  },
]);
