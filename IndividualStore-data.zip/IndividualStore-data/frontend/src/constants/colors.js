const GREEN = "#18bc9c";
const LIGHT_RED = "#e46f6f";

export const COLORS = {
  GREEN,
  LIGHT_RED,
};
