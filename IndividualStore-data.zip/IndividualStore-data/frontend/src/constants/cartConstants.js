// 更新购物车中项目的购买数量
export const CART_UPATE_ITEM_COUNT = "const CART_UPATE_ITEM_COUNT";

// 添加新项目或更新已存在项目的购买数量
export const CART_ADD_OR_UPDATE_ITEM = "CART_ADD_OR_UPDATE_ITEM";

// 移除项目
export const CART_REMOVE_ITEM = "CART_REMOVE_ITEM";

// 替换(更新)购物车中的项目
export const CART_REPLACE_ITEMS = "CART_REPLACE_ITEMS";

// 更新项目被选中的状态
export const CART_UPDATE_ITEM_SELECTED_STATE =
  "CART_UPDATE_ITEM_SELECTED_STATE";

// 清空购物车中所有项目
export const CART_CLEAR_ALL_ITEMS = "CART_CLEAR_ITEMS";

// 保存地址
export const CART_SAVE_SHIPPING_ADDRESS = "CART_SAVE_SHIPPING_ADDRESS";

// 选择支付模式
export const CART_SAVE_PAYMENT_METHOD = "CART_SAVE_PAYMENT_METHOD";
