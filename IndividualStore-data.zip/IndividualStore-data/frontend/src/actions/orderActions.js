import axios from "axios";
import { ORDER_ACT_TYPES } from "../constants/orderConstants";
import { backendApiURL, defaultValues } from "../config/config";

export const orderCeatedAct = (order) => async (dispatch, getState) => {
  // console.log(order);
  try {
    // 获取已登录用户的token
    const { userInfo } = getState().userInfoReducer; // console.log(userInfo);
    const token = userInfo.token;
    if (!token) {
      throw new Error("error: missed user identification token.");
    }
    // 请求
    dispatch({ type: ORDER_ACT_TYPES.ORDER_CREATED_REQUEST });
    // 处理，订单数据发送给后端
    const authToken = defaultValues.tokenPrefix + " " + token; // console.log(authToken);
    const { data } = await axios.post(backendApiURL.orders, order, {
      headers: {
        "Content-Type": "application/json",
        Authorization: authToken,
      },
    });
    // console.log(data);
    // 成功
    dispatch({ type: ORDER_ACT_TYPES.ORDER_CREATED_SUCCESS, payload: data });
  } catch (error) {
    console.error(error);
    // 错误
    dispatch({
      type: ORDER_ACT_TYPES.ORDER_CREATED_FAIL,
      payload: error.message,
    });
  }
};
