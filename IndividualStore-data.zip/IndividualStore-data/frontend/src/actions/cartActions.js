import axios from "axios";
import {
  CART_ADD_OR_UPDATE_ITEM,
  CART_REMOVE_ITEM,
  CART_UPDATE_ITEM_SELECTED_STATE,
  CART_REPLACE_ITEMS,
} from "../constants/cartConstants";

// 添加项目到购物车
export const addORupdateCartAct =
  (productId, count, ACION_TYPE = CART_ADD_OR_UPDATE_ITEM) =>
  async (dispatch, getState) => {
    // 根据productId获取数据
    const { data: product } = await axios.get(`/api/products/${productId}`);
    // console.log(product?.name, "[addToCart action]");

    // 派发购物车数据对象给Reducer进行更新
    dispatch({
      type: ACION_TYPE,
      payload: {
        productId: product._id,
        name: product.name,
        image: product.image,
        price: product.price,
        countInStock: product.countInStock, // 【库存是否需要缓存到本地？隐私数据】xxxx
        count: Number(count), // 购买数量、或者更新数量比如+1、-1
        isSelected: false, // 是否勾选(购买)状态
        isPaid: false,
      },
    });

    // 将购物车中的所有项目缓存到本地
    localStorage.setItem(
      "cartItems",
      JSON.stringify(getState().cartReducer.cartItems)
    );
  };

// 根据productId移除某个产品
export const removeFromCartAct = (productId) => async (dispatch, getState) => {
  dispatch({
    type: CART_REMOVE_ITEM,
    payload: {
      productId,
    },
  });

  // 更新本地购物车缓存的产品数据
  localStorage.setItem(
    "cartItems",
    JSON.stringify(getState().cartReducer.cartItems)
  );
};

// 更新购物车中的项目
export const replceItemsInCartAct =
  (newCartItems) => async (dispatch, getState) => {
    dispatch({
      type: CART_REPLACE_ITEMS,
      payload: {
        newCartItems,
      },
    });

    // 更新本地购物车缓存的产品数据
    localStorage.setItem(
      "cartItems",
      JSON.stringify(getState().cartReducer.cartItems)
    );
  };

// 选中产品，更新勾选状态
export const updateItemIsSelectedAct =
  (productId, isSelectedAll = false, isCancelAll = false) =>
  async (dispatch, getState) => {
    dispatch({
      type: CART_UPDATE_ITEM_SELECTED_STATE,
      payload: {
        productId,
        isSelectedAll,
        isCancelAll,
      },
    });

    // 更新本地购物车缓存的产品数据
    localStorage.setItem(
      "cartItems",
      JSON.stringify(getState().cartReducer.cartItems)
    );
  };
