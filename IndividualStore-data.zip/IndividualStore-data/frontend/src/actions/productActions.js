import axios from "axios";
import {
  PRODUCT_LIST_FAIL,
  PRODUCT_LIST_REQUEST,
  PRODUCT_LIST_SUCCESS,
} from "../constants/productConstants";

// 获取所有产品
export const getProductListAct = () => async (dispatch) => {
  try {
    // 更新为请求状态
    dispatch({ type: PRODUCT_LIST_REQUEST });
    // 获取(最新)数据
    const { data } = await axios.get("/api/products");
    // 更新数据
    dispatch({ type: PRODUCT_LIST_SUCCESS, payload: data });
  } catch (error) {
    // 报告错误信息
    dispatch({
      type: PRODUCT_LIST_FAIL,
      payload: error,
    });
  }
};
