import axios from "axios";
import {
  USER_CONSTANTS as TYPE,
  USER_CONSTANTS,
} from "../constants/userConstants";

// 用户登录
export const userLoginAct = (email, password) => async (dispatch) => {
  try {
    // 初始state为请求状态
    dispatch({ type: TYPE.USER_LOGIN_REQUEST });

    // 获取登录成功后返回的用户信息，并更新state记录以登录的用户信息
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    const { data } = await axios.post(
      "/api/users/login",
      { email, password },
      config
    );
    dispatch({
      type: TYPE.USER_LOGIN_SUCCESS,
      payload: data,
    });
    // console.log(data);

    // 成功登录的用户缓存到本地
    localStorage.setItem("userInfo", JSON.stringify(data.userInfo));
  } catch (error) {
    // 登录失败，更新state
    const resErrorMessage = error.response?.data?.message;
    dispatch({
      type: TYPE.USER_LOGIN_FAIL,
      payload: error.message + (resErrorMessage ? ` : ${resErrorMessage}` : ""),
    });
  }
};

// 用户退出
export const userLogoutAct = () => async (dispatch) => {
  // 清空本地缓存
  localStorage.removeItem("userInfo");
  // 派发退出相关的action对象
  dispatch({
    type: USER_CONSTANTS.USER_LOGOUT,
    payload: { userInfo: null },
  });
};

// 用户注册
export const userRegisterAct = (name, email, password) => async (dispatch) => {
  try {
    // 初始state为请求状态
    dispatch({ type: TYPE.USER_REGISTER_REQUEST });

    // 获取注册成功后返回的用户信息
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    const { data } = await axios.post(
      "/api/users/register",
      { name, email, password },
      config
    );
    // console.log(data);

    // 更新用户注册状态
    dispatch({ type: TYPE.USER_REGISTER_SUCCESS, payload: data });

    // 更新登录用户状态，注册成功的用户可以直接登录
    dispatch({ type: TYPE.USER_LOGIN_SUCCESS, payload: data });

    // 成功登录的用户缓存到本地
    localStorage.setItem("userInfo", JSON.stringify(data.userInfo));
  } catch (error) {
    // 注册失败，更新state
    const resErrorMessage = error.response?.data?.message;
    dispatch({
      type: TYPE.USER_REGISTER_FAIL,
      payload: error.message + (resErrorMessage ? ` : ${resErrorMessage}` : ""),
    });
  }
};

// 用户资料更新
export const userUpdateInfoAct =
  (name, email, password) => async (dispatch) => {
    try {
      // 发送PUT报文，请求后端更新数据
      const { data } = await axios.put(
        "/api/users/profile",
        { name, email, password },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("put data: ", data);

      // 更新登录用户状态
      dispatch({ type: TYPE.USER_LOGIN_SUCCESS, payload: data });

      // 成功登录的用户缓存到本地
      localStorage.setItem("userInfo", JSON.stringify(data.userInfo));
    } catch (error) {
      // 更新失败
      const resErrorMessage = error.response?.data?.message;
      dispatch({
        type: TYPE.USER_UPDATE_PROFILE_FAIL,
        payload:
          error.message + (resErrorMessage ? ` : ${resErrorMessage}` : ""),
      });
    }
  };
