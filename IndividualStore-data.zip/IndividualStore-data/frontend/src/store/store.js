import {
  legacy_createStore as createStore,
  combineReducers,
  applyMiddleware,
} from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import { getFromLocalStorage } from "../utils/utils";
import { productListReducer } from "../reducers/productReducers";
import { cartReducer } from "../reducers/cartReducers";
import { userInfoReducer } from "../reducers/userReducers";
import { orderReducer } from "../reducers/orderReducers";

// 所有状态处理程序
const reducer = combineReducers({
  productListReducer,
  cartReducer,
  userInfoReducer,
  orderReducer,
});

// 设置Reducer的初始化状态
// 【改进: 将这些数据保存在数据库，初始时从数据库获取】
const initialState = {
  cartReducer: { cartItems: getFromLocalStorage("cartItems") || [] },
  userInfoReducer: { userInfo: getFromLocalStorage("userInfo") || {} },
  orderReducer: { orderSubmitted: {} },
};

// 中间件(数组存储)
const middlewares = [thunk];

// 仓库
const store = createStore(
  reducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middlewares))
);

export default store;
