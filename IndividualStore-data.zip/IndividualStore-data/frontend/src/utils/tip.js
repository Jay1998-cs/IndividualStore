export const tipFunc = (text) => {
  console.warn("######### 待修改内容: ", text);
};
