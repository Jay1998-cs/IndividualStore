// 获取本地缓存的数据
export const getFromLocalStorage = (key = "") => {
  // expample:
  // const cartItemsFromLocalStorage = localStorage.getItem("cartItems");
  // const cartItems = cartItemsFromLocalStorage
  //   ? JSON.parse(cartItemsFromLocalStorage)
  //   : [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : null;
};

////////////////////////////// 正则 ///////////////
// 验证登录名称是否合法

// 验证用户邮箱是否合法
// export const checkUserEmil = (email = "") => {};

// 验证用户姓名是否合法
export const checkUserName = (name = "") => {
  if (!name) {
    throw new Error("用户名不能为空!");
  }
  if (!Object.is(Number(name[0]), NaN)) {
    throw new Error("用户名开头不能为数字!");
  }
  if (!Object.is(Number(name), NaN)) {
    throw new Error("用户名不能全为数字!");
  }

  return true;
};

// 验证电话是否合法
export const checkPhoneNumber = (phone = "") => {
  if (!phone) {
    throw new Error("手机号不能为空!");
  }

  if (Object.is(Number(phone), NaN)) {
    throw new Error("手机号只包含数字!");
  }

  if (String(phone).length !== 11) {
    throw new Error("手机号必需为11位!");
  }

  const strArr = phone.split("");
  const isInValid = strArr.some((s) => s === "." || s === "e");
  if (isInValid) {
    throw new Error("手机号只包含数字!");
  }

  return true;
};

// 验证寄件地址是否合法
export const checkShippingAdress = (address = "") => {
  if (!address) {
    throw new Error("地址不能为空!");
  }
  if (address.length < 8) {
    throw new Error("地址较简洁，请填写更详细的地址");
  }
  if (!Object.is(Number(address[0]), NaN)) {
    throw new Error("地址开头不能为数字!");
  }

  return true;
};

// 保留两位小数
export const fixed2Number = (num) => {
  num = Number(num);
  return (Math.floor(num * 100) / 100).toFixed(2);
};
